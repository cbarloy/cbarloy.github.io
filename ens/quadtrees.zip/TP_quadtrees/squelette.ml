# load "graphics.cma" ;;

(* Introduction *)

type pixel = Blanc | Noir

type bitmap = pixel array array

let rec find_in_list l x = 
  0

let char_to_int = 
  0

let rec string_to_int str = 
  0

let test_q2 () =
  assert (string_to_int "5243" = 5243);
  assert (string_to_int "54627845" = 54627845)

let load_bitmap file =
    [|[|Blanc|]|] 

let test_q3 () =
  let bmap = load_bitmap "exemples/toy.txt" in
  assert( bmap = [| [| Noir; Noir; Blanc; Blanc |];
                    [| Noir; Blanc; Blanc; Blanc |];
                    [| Blanc; Blanc; Blanc; Blanc |];
                    [| Blanc; Blanc; Blanc; Noir |] |]);;

(* Les quadtrees *)

type quadtree =
  |Feuille of pixel
  |Noeud of quadtree * quadtree * quadtree * quadtree

let rec taille t =
  0

let bitmap_to_quadtree bmap =
    Feuille Blanc
  
let test_q6 () =
  let bmap = load_bitmap "exemples/toy.txt" in
  let qtree = bitmap_to_quadtree bmap in
  assert (qtree = Noeud( Noeud(Feuille Noir,Feuille Noir,Feuille Noir,Feuille Blanc),
                         Noeud(Feuille Blanc,Feuille Blanc,Feuille Blanc,Feuille Blanc),
                         Noeud(Feuille Blanc,Feuille Blanc,Feuille Blanc,Feuille Blanc),
                         Noeud(Feuille Blanc,Feuille Blanc,Feuille Blanc,Feuille Noir)));;

(* Compression *)
  
let rec compress t = 
  Feuille Blanc

let test_q7 () =
  let bmap = load_bitmap "exemples/toy.txt" in
  let qtree = compress (bitmap_to_quadtree bmap) in
  assert (qtree = Noeud( Noeud(Feuille Noir,Feuille Noir,Feuille Noir,Feuille Blanc),
                         Feuille Blanc,
                         Feuille Blanc,
                         Noeud(Feuille Blanc,Feuille Blanc,Feuille Blanc,Feuille Noir)))

let save_quadtree t file =
  ()

let load_quadtree file =
  Feuille Blanc
  
let test_q10() =
  let bmap = load_bitmap "exemples/toy.txt" in
  let qtree = compress (bitmap_to_quadtree bmap) in
  save_quadtree qtree "exemples/compressed_toy.txt";
  assert (qtree = load_quadtree "exemples/compressed_toy.txt")

(* Dessin *)

let rec draw_quadtree t i j k= 
  ()

let rec rotation t = 
  Feuille Blanc
                        
let rec anti_rotation t =
  Feuille Blanc
                        
let rec symetrie t = 
  Feuille Blanc
                        
let rec inversion t = 
  Feuille Blanc
                        
let start_drawing t =
  Graphics.open_graph (" 512x512");
  draw_quadtree t 0 0 512;
  let rec loop t =
    let c = Graphics.read_key () in
    if c = 'q' then ()
    else loop t
  in
  loop t                     

let test_q16 () = 
  let bmap = load_bitmap "exemples/pikachu.txt" in
  let qtree = compress (bitmap_to_quadtree bmap) in
  start_drawing qtree
